<script>
    import TodoForm from "./QuestionForm.svelte";
    import TodoList from "./QuestionList.svelte";
  
</script>
  
<h1>Questions</h1>
  
<h2>Add a Question</h2>

<TodoForm />
  
<h2>Existing questions:</h2>
  
<TodoList />