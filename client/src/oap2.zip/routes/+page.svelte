<script>
    import Questions from "../lib/components/Questions.svelte";
</script>
  
<Questions />
