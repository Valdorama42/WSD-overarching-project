<div class="min-h-screen flex flex-col items-center justify-center bg-gray-20">
  <h1 class="text-5xl font-bold text-gray-800 mb-4">Welcome!</h1>
</div>